(() => {
    const rejectTexts = [
        "Reject", "Only necessary", "Decline", "Reject all", "Deny", "No thanks", "Disagree"
    ];
    const selectors = [
        '[id*="cookie"]',
        '[class*="cookie"]',
        '[aria-label*="cookie"]',
        '[data-testid*="cookie"]',
        '[role="dialog"]',
        '[id*="consent"]',
        '[class*="consent"]'
    ];

    function removeCookieElements() {
        let found = false;
        selectors.forEach(sel => {
            document.querySelectorAll(sel).forEach(container => {
                container.querySelectorAll("button, input[type='button'], a").forEach(el => {
                    if (
                        (el.offsetParent !== null) &&
                        (
                            rejectTexts.some(t => el.innerText?.toLowerCase().includes(t.toLowerCase())) ||
                            rejectTexts.some(t => el.value?.toLowerCase().includes(t.toLowerCase()))
                        )
                    ) {
                        el.click();
                        found = true;
                    }
                });
                container.remove();
                found = true;
            });
        });

        if (found) {
            document.body.style.setProperty('overflow', 'auto', 'important');
            document.body.style.setProperty('position', 'static', 'important');
            document.body.style.setProperty('margin-top', '0px', 'important');
            document.body.style.setProperty('top', '0px', 'important');
            document.body.style.setProperty('left', '0px', 'important');
            document.body.style.setProperty('right', '0px', 'important');
            document.body.classList.remove('cookie-consent', 'cookie-banner', 'cookie-notice', 'cookie-popup');
        }

        return found;
    }

    const intervalId = setInterval(() => {
        if (removeCookieElements()) {
            clearInterval(intervalId);
        }
    }, 200);
})();
